setTimeout(() => {
  document.querySelector('.pm-loader-text-container').classList.add('visible');
}, 10000);
