const { session } = require('electron'),

  FUNCTION = 'function';

/**
 * CookieManager on main process allows to interact with session cookies from
 * the main process.
 */
class CookieManager {

  constructor (partitionId) {
    this.cookieStore = CookieManager.getCookieStore(partitionId);
  }

  static getCookieStore (partitionId) {
    return session.fromPartition(String(partitionId)).cookies;
  }

  get (filter, callback) {
    const callbackMode = typeof callback === FUNCTION;

    return this.cookieStore.get(filter).then((cookies) => {
      if (callbackMode) {
        return callback(null, cookies);
      }

      return cookies;
    }).catch((error) => {
      if (callbackMode) {
        return callback(error);
      }

      throw error;
    });
  }

  set (details, callback) {
    const callbackMode = typeof callback === FUNCTION;

    return this.cookieStore.set(details).then((cookie) => {
      if (callbackMode) {
        return callback(null, cookie);
      }

      return cookie;
    }).catch((error) => {
      if (callbackMode) {
        return callback(error);
      }

      throw error;
    });
  }

  remove (details = {}, callback) {
    const callbackMode = typeof callback === FUNCTION;

    return this.cookieStore.remove(details.url, details.name).then(() => {
      if (callbackMode) {
        return callback(null);
      }
    }).catch((error) => {
      if (callbackMode) {
        return callback(error);
      }

      throw error;
    });
  }

  // @note Disabled: not required
  // flushStore (callback) {
  //   const callbackMode = typeof callback === FUNCTION;

  //   return this.cookieStore.flushStore().then(() => {
  //     if (callbackMode) {
  //       return callback(null);
  //     }
  //   }).catch((error) => {
  //     if (callbackMode) {
  //       return callback(error);
  //     }

  //     throw error;
  //   });
  // }
}

module.exports = CookieManager;
