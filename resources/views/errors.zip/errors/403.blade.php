<!DOCTYPE html>
<html>
<head>
	<title>Access Denied</title>
	 <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>

<body>
	
			<img src="{{asset('error.jpg')}}" style="display: block;
  margin-left: auto;
  margin-right: auto;
  width: 40%;"><br>
	<div style="display: block;
  margin-left: auto;
  margin-right: auto;
  width: 40%;">
  <a href="{{route('index')}}">Click here to go back</a>
	</div>
	
	
</body>
</html>